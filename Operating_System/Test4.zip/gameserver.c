#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdlib.h>
#include <time.h>


void * serverthread(void * parm);       /* thread function prototype    */
void * evalthread();       /* thread function prototype    */

pthread_mutex_t  mut;

#define PROTOPORT         5193          /* default protocol port number */
#define QLEN              6             /* size of request queue        */
#define MAXTEXT		100
int visits =  0;                        /* counts client connections     */


int evalgame(char,char);
main (int argc, char *argv[])
{
     struct   hostent   *ptrh;     /* pointer to a host table entry */
     struct   protoent  *ptrp;     /* pointer to a protocol table entry */
     struct   sockaddr_in sad;     /* structure to hold server's address */
     struct   sockaddr_in cad;     /* structure to hold client's address */
     int      sd, sd2;             /* socket descriptors */
     int      port;                /* protocol port number */
     int      alen;                /* length of address */
     pthread_t  tid;             /* variable to hold thread ID */
     pthread_t  eid;             /* variable to hold thread ID */

 pthread_mutex_init(&mut, NULL);
     memset((char  *)&sad,0,sizeof(sad)); /* clear sockaddr structure   */
     sad.sin_family = AF_INET;            /* set family to Internet     */
     sad.sin_addr.s_addr = INADDR_ANY;    /* set the local IP address */

     /* Check  command-line argument for protocol port and extract      */
     /* port number if one is specfied.  Otherwise, use the default     */
     /* port value given by constant PROTOPORT                          */

     if (argc > 1) {                        /* if argument specified     */
                     port = atoi (argv[1]); /* convert argument to binary*/
     } else {
                      port = PROTOPORT;     /* use default port number   */
     }
     if (port > 0)                          /* test for illegal value    */
                      sad.sin_port = htons((u_short)port);
     else {                                /* print error message and exit */
                      fprintf (stderr, "bad port number %s/n",argv[1]);
                      exit (1);
     }

     /* Map TCP transport protocol name to protocol number */

     if ( ((int)(ptrp = getprotobyname("tcp"))) == 0)  {
                     fprintf(stderr, "cannot map \"tcp\" to protocol number");
                     exit (1);
     }
 /* Create a socket */
     sd = socket (PF_INET, SOCK_STREAM, ptrp->p_proto);
     if (sd < 0) {
                       fprintf(stderr, "socket creation failed\n");
                       exit(1);
     }
 /* Bind a local address to the socket */
     if (bind(sd, (struct sockaddr *)&sad, sizeof (sad)) < 0) {
                        fprintf(stderr,"bind failed\n");
                        exit(1);
     }

     /* Specify a size of request queue */
     if (listen(sd, QLEN) < 0) {
                        fprintf(stderr,"listen failed\n");
                         exit(1);
     }

     alen = sizeof(cad);

     pthread_create(&eid, NULL, evalthread, NULL); //eval thread run first

     /* Main server loop - accept and handle requests */
     fprintf( stderr, "Server up and running.\n");
     while (1) {

         printf("SERVER: Waiting for contact ...\n");

         if (  (sd2=accept(sd, (struct sockaddr *)&cad, &alen)) < 0) {
	                      fprintf(stderr, "accept failed\n");
                              exit (1);
	 }
	pthread_create(&tid, NULL, serverthread, (void *) sd2 );

     } /* end of while */
  close(sd);
}
void * serverthread(void * parm)
{
   int tsd;
   char buf[100];           /* buffer for string the server sends */
   int n;
   pthread_t id;
   int mqid;
   // struct gameid my_data;

   tsd = (int) parm;
   pthread_mutex_lock(&mut);
        ++visits;
        printf(" %d clients connected...\n",visits);
   pthread_mutex_unlock(&mut);

   if ( visits == 1) {
      if((mqid = msgget((key_t)1234,0666|IPC_CREAT)) == -1) {
          printf("1234 msgget failed \n");
          pthread_exit(0);
      }
   } else if ( visits == 2) {
      if((mqid = msgget((key_t)1235,0666|IPC_CREAT))== -1) {
          printf("1235 msgget failed \n");
          pthread_exit(0);
      }
   }

   id = pthread_self();
   sprintf(buf,"Your PID in Server is %u .. \n", (unsigned int)id);
   printf("SERVER thread: %s .. waiting..\n", buf);
   send(tsd,buf,strlen(buf),0);

    while (1)  {
   n = recv(tsd,buf,sizeof(buf),0);
   buf[n]='\0';
   printf("Server thread : you type ->  %s\n", buf);
   
   int bf;
   if((int)buf[0]-'0' <= 10){
   	bf = 1;
   }
   else{
   	bf = 2;
   }
   switch (bf) 
   {
     case 1 :
              msgsnd(mqid,buf,MAXTEXT,0);
              printf("Server thread : send it to evalthread \n");
           break;
     case 2 :
            sprintf(buf," Finish game .. \n");
            send(tsd,buf,strlen(buf),0);
            printf("SERVER thread: %u .. exit()..", id);
            if(msgctl(mqid,IPC_RMID,NULL) == -1) {
                 printf("msgctl failed \n");
            }
            close(tsd);
            pthread_exit(0);
           break;
     default : 
            sprintf(buf," invalid  input.. try again.. \n");
            send(tsd,buf,strlen(buf),0);
           break;
   }
   if(msgrcv(mqid,buf,MAXTEXT,0,MSG_NOERROR)== -1) {
                  printf("mq_b msgrcv failed with error \n");
		  pthread_exit(0);
   }
   printf("SERVER : thread(%u) is  %s \n",id,buf);
   send(tsd,buf,strlen(buf),0);
   buf[0]='\0';  // clear buff string
   } /** end of while */
}

void *evalthread()
{
     int t;
     int mqid_a;
     int mqid_b;
     char bufA[10],bufB[10];
     key_t key_qa = 1234,key_qb=1235;

     printf("SERVER: eval thread running .\n");
     if((mqid_a = msgget(key_qa,IPC_CREAT|0666)) == -1) {
           printf("key_qa msgget failed \n");
           pthread_exit(0);
     }
     if((mqid_b = msgget(key_qb,IPC_CREAT|0666)) == -1) {
           printf("key_qb msgget failed \n");
           pthread_exit(0);
     }
     printf(" two message queues connected\n");
     while(1) {
        bufA[0] = '\0';
        bufB[0] = '\0';
         if(msgrcv(mqid_a,bufA,MAXTEXT,0,MSG_NOERROR)== -1) {
                  printf("mg_a msgrcv failed with error \n");
		  pthread_exit(0);
         }
         printf(" I get one and waiting : A-> %s \n",bufA);

         if(msgrcv(mqid_b,bufB,MAXTEXT,0,MSG_NOERROR)== -1) {
                  printf("mq_b msgrcv failed with error \n");
		  pthread_exit(0);
         }
         printf(" I get two and eval it : B-> %s \n",bufB);

         if(bufA[0] != '\0' && bufB[0] != '\0') {
             t = evalgame(bufA[0],bufB[0]);  
             printf("SERVER evalgame: eval -> %d\n",t);

             switch(t) {
             case 0 :
                     
                     strcpy(bufA,"Try Again");
                     strcpy(bufB,"Try Again");
                     break;
             case 1 :
                     strcpy(bufA,"You Win!");
                     strcpy(bufB,"You loose.");
                     break;
             case 2 :
                     strcpy(bufA,"You loose.");
                     strcpy(bufB,"You Win!");
                     break;

            }  /* end of switch */
            msgsnd(mqid_a,bufA,MAXTEXT,0);
            msgsnd(mqid_b,bufB,MAXTEXT,0);
         } // end of if
    } /* end of whie */
}

int evalgame(char a,char b)
{
	srand(time(NULL)); // 난수 초기화
	int random = rand() % 10; // 0~9 사이의 숫자를 뽑아서 random 변수에 저장
	//printf("random value => %d %d %d %c %c\n ", random,(int)a,(int)b,a,b); // 출력
	printf("random value => %d \n", random); // 출력
	
	int ta = (int)a -48 -random;
	int tb = (int)b -48 -random;
	printf("ta, tb value => %d %d \n ", ta,tb);
	if (ta == tb){
	return 0;
	}
	else if(ta < tb){
	return 2;
	}
	else if(ta > tb){
	return 1;
	}

}  /** end of evalgame */




