#include <stdlib.h>  
#include <stdio.h>  
   
int main(int argc, char *argv[])  
{  
        int i;
        int mul = 1;  
        /* 받아온 매개 변수값이 맞는지 한번 출력해줌 */
        for (i = 0; i < argc; i++)  
                printf("argv[%d]: %s\n", i, argv[i]);
        /* 받아온 매개 변수값들로 곱셈을 진행함 */ 
        for (i = 1; i < argc; i++) 
        	mul *= atoi(argv[i]); 
        printf("Multiplication result = %d\n",mul);
        exit(0);  
}
