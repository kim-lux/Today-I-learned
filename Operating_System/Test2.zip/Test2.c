#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

#define MAXARGC 20
#define MAXLINE 80
int execute(char **);
char** gettoken(char *);

int main()
{
   char line[MAXLINE], *token;
   char **args;
   int status=0;

   printf("My Shell Started.... \n");

   while(1) {

      printf("MyShell>");
      fgets(line,MAXLINE,stdin);
   
      if (strncmp(line,"quit",4) != 0) {
         args = gettoken(line);
         status = execute(args);
         printf("\n");

       } else {
           exit(1);
       }

   } /* end of while*/

   free(args);

   return(1);

}

char ** gettoken(char *line)
{

   int idx = 0;
   char delim[] = " \t\r\n";
   char **tokenList = (char **)malloc(MAXLINE);
   char *token;

   if(!tokenList) {
      printf("malloc error \n");
      exit(EXIT_FAILURE);
    }

   token = strtok(line,delim);
   while(token != NULL) {
      tokenList[idx] = token;
      idx++;

      if(idx > MAXARGC-1) {
         printf("Too many args  \n");
         break;
      }
      token = strtok(NULL,delim);
   } // end of while

   tokenList[idx] = NULL; // insert end of string mark
   return tokenList;

} // end of gettoken

int execute(char** args)
{
    pid_t pid;
    int status;
    int i = 1;
    
    /* 어떤 명령어를 받아 올 수 있는지 정의 */
    char *p = "p";
    char *m = "m";
    char *ls = "ls";	
    char *cd = "cd";	

    if(args[0] == NULL) { // empty command
        return 1;
    }
    /*  
    // 매개변수 값을 잘 받아 왔는지 확인
    printf(" %s ", args[0]);
    while (args[i] != NULL) {

        printf(" %s ", args[i]);
        i++;

    }
    */
    printf("\n");
	/* fork a child process */
	pid = fork();
	if (pid < 0)
	{
		/*error occurred*/
		fprintf(stderr, "Fork Failed\n");
		return 1;
	}
	else if ( pid == 0 )
	{
		/* child process */
		if (strcmp(args[0], p) == 0) /* 명령어로 p(Plus)를 받아 들이고 매개변수를 최대 4개씩 받아 올 수 있음 */
		{
			execlp("/home/kim/Os/Test_2/mybin/p","p",args[1],args[2],args[3],args[4],NULL);
		}
		else if (strcmp(args[0], m) == 0) /* 명령어로 m(Multiplication)를 받아 들이고 매개변수를 최대 4개씩 받아 올 수 있음 */
		{
			execlp("/home/kim/Os/Test_2/mybin/m","m",args[1],args[2],args[3],args[4],NULL);
		}
		else if (strcmp(args[0], ls) == 0) /* 명령어로 ls를 받아 들이고 실행함 */
		{
			//execlp("ls", "ls", "-al", NULL); /* 명령어로 ls -a로 변경하여 사용가능 */
			execlp("ls", "ls", NULL);
		}
		else if (strcmp(args[0], cd) == 0) /* 명령어로 cd를 받아 들이고 실행함 */
		{
			chdir(args[1]); 
		}
		else /* 정의된 명령어가 아닌 다른 값이 들어왔을 경우 */
		{
			printf("Please collect command");
		}
		
	}
	else
	{
		/* parent process */
		wait(NULL);
        /*Child process가 끝날때 까지 기다림*/
		//printf("Child Complete\n"); 	
	}
    //printf("End of fork\n");
    return (1);
}// end of execute1
