#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>

// 변수선언
long bias = 0;
long maxTry = 999;
int maxThreads = 10;
long t0cnt = 0;
long t1cnt = 0;

void *plus(void *arg);
void *minus(void *arg);
long swap(long x);

/**/
pthread_mutex_t mutex;
/**/

int main(int argc, char *argv[])
{
  //thread 선언
    pthread_t plu[100], minu[100];
    int retval;
    int i;

    if (argc <= 1) // 매개변수가 1개가 들어왔거나 들어오지 않았을 때
    {
        printf("please collect command");
        exit(1);
    }
    if (argc >= 2) // 매개변수가 2개이상 들어왔을때
    {
        bias = atoi(argv[1]);
        maxTry = atoi(argv[2]);
    }

    if (argc > 3) 
    {
        maxThreads = atoi(argv[3]);
    }
    printf("Start Balance -> %ld , MaxTry -> %ld, MaxThreads -> %d\n", bias, maxTry, maxThreads);

    /**/
    retval = pthread_mutex_init(&mutex,NULL);
    /**/
    //Thread를 mutex를 이용할 것인지 코드에 주석으로 선택한 다음 thread를 실행
    for (i = 0 ; i < maxThreads ; i++)
    {
        retval = pthread_create(&plu[i],NULL,plus,NULL);
        retval = pthread_create(&minu[i],NULL,minus,NULL);
    }
    for (i = 0 ; i < maxThreads ; i++)
    {
        retval = pthread_join(plu[i],NULL);
        retval = pthread_join(minu[i],NULL);
    }

    /**/
    retval = pthread_mutex_destroy(&mutex);
    /**/

    printf("Final Balance -> %ld\n",bias);

    return 0;
}

//bias에서 +i
void *plus(void *arg)
{
    long i;
    short ran;

    for (i = 0; i < maxTry; i++)
    {
        /**/
        pthread_mutex_lock(&mutex);
        /**/
        bias = bias + i;
        bias = swap(bias);
        /**/
        pthread_mutex_unlock(&mutex);
        /**/
    }

    printf("plus thread : maxTry -> %ld, plus thread execution cnt -> %ld , bias -> %ld\n", maxTry, t0cnt++, bias);

    pthread_exit(0);
}

//bias에서 -i
void *minus(void *arg)
{
    long i;
    short ran;

    
    for (i = 0; i < maxTry; i++)
    {
        /**/
        pthread_mutex_lock(&mutex);
        /**/
        bias = bias - i;
        bias = swap(bias);
        /**/
        pthread_mutex_unlock(&mutex);
        /**/
    }

    printf("minus thread : maxTry -> %ld, minus thread execution cnt -> %ld , bias -> %ld\n", maxTry, t1cnt++,bias);

    pthread_exit(0);    
}

// Error를 일부러 잘일어나게 하기위해 Swap을 넣음
long swap(long x)
{
    long tmp;
    int i;

    for(i = 0; i < 100; i++)
    {
        tmp = x;
        x = tmp;
    }

    return x; 
}
